# Ulam Planner 7 Days PRO

MCSN AppFactory • Gemini Batch (App #19)

- Screens: Home / Input / Resulta / Tapos Na
- Logic: Menu -> Grocery List
- Offline, mobile-first, vanilla JS (localStorage)

## Install (PWA)
I-serve ang folder na ito (hal. `python3 -m http.server`), buksan sa Chrome, tapos **Add to Home Screen**.

## Images (para sa Gemini-generated screenshots)
Ilagay sa `images/` folder: `1-home.png`, `2-ginagamit.png`, `3-resulta.png`, `4-tapos.png`.
